from .app_config import DifyConfig

dify_config = DifyConfig()
