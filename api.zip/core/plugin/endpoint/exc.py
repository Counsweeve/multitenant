class EndpointSetupFailedError(ValueError):
    """
    Endpoint setup failed error
    """

    pass
